﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Channels;

namespace userInteraction
{
    class program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Details of a single recipe");
            Console.WriteLine("***********************************************");

            Console.Write("Enter the number of ingridients: ");
            string myIngridients;
            myIngridients = Console.ReadLine();

            Console.Write("Enter the name, quantity and measurement: ");
            string myName;
            myName = Console.ReadLine();

            Console.Write("Enter a description of the steps: ");
            string myDescription = Console.ReadLine();

            string newIngridients = myIngridients;
            Console.WriteLine("***********************************************");
            Console.WriteLine("Your recipe is: " + "The ingridients are: " + myIngridients + " |The measurements are: " +   myName  + "|" + " Follow this steps to prepare the meal: " + myDescription);
            Console.ReadLine();
        }
    }
}

